package com.zorbix.fpsboost;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class FpsBoostClient implements ClientModInitializer {
    public static final String MOD_ID = "fpsboost";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = Path.of("config", "fpsboost.json");

    private FpsBoostConfig config;
    private KeyBinding toggleKey;
    private boolean enabled;
    private boolean savedOriginalDistance;
    private int originalRenderDistance = -1;
    private int tickCounter;
    private boolean reduced;

    @Override
    public void onInitializeClient() {
        config = loadConfig();
        enabled = config.enabled;

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fpsboost.toggle",
                GLFW.GLFW_KEY_F8,
                "key.categories.fpsboost"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
    }

    private void onClientTick(MinecraftClient client) {
        while (toggleKey.wasPressed()) {
            toggle(client);
        }

        if (!enabled || client.player == null || client.world == null) {
            return;
        }

        tickCounter++;
        if (tickCounter < Math.max(1, config.checkIntervalTicks)) {
            return;
        }
        tickCounter = 0;

        int current = client.options.getViewDistance().getValue();
        if (!savedOriginalDistance) {
            originalRenderDistance = current;
            savedOriginalDistance = true;

            // Respect the configured safety ceiling while the boost is active.
            if (current > config.maximumRenderDistance) {
                client.options.getViewDistance().setValue(config.maximumRenderDistance);
                current = config.maximumRenderDistance;
                reduced = true;
            }
        }

        int fps = client.getCurrentFps();

        if (fps > 0 && fps < config.lowFpsThreshold) {
            int target = Math.max(config.minimumRenderDistance,
                    Math.min(config.maximumRenderDistance,
                            current - Math.max(1, config.reductionStep)));
            if (target != current) {
                client.options.getViewDistance().setValue(target);
                reduced = true;
                if (config.showStatusMessages) {
                    client.player.sendMessage(
                            Text.translatable("fpsboost.message.reduced", target), true);
                }
            }
        } else if (fps >= config.recoveryFpsThreshold && current < originalRenderDistance) {
            int target = Math.min(originalRenderDistance,
                    current + Math.max(1, config.reductionStep));
            client.options.getViewDistance().setValue(target);
            if (target >= originalRenderDistance) {
                reduced = false;
            }
            if (config.showStatusMessages) {
                client.player.sendMessage(
                        Text.translatable("fpsboost.message.restored", target), true);
            }
        }
    }

    private void toggle(MinecraftClient client) {
        enabled = !enabled;
        config.enabled = enabled;
        saveConfig();

        if (enabled) {
            savedOriginalDistance = false;
            reduced = false;
            if (client.player != null) {
                client.player.sendMessage(
                        Text.translatable("fpsboost.message.enabled"), true);
            }
        } else {
            restoreSettings(client);
            if (client.player != null) {
                client.player.sendMessage(
                        Text.translatable("fpsboost.message.disabled"), true);
            }
        }
    }

    private void restoreSettings(MinecraftClient client) {
        if (savedOriginalDistance && originalRenderDistance >= 2) {
            client.options.getViewDistance().setValue(originalRenderDistance);
        }
        savedOriginalDistance = false;
        originalRenderDistance = -1;
        reduced = false;
    }

    private FpsBoostConfig loadConfig() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            if (Files.notExists(CONFIG_PATH)) {
                FpsBoostConfig defaults = new FpsBoostConfig();
                Files.writeString(CONFIG_PATH, GSON.toJson(defaults));
                return defaults;
            }

            FpsBoostConfig loaded = GSON.fromJson(Files.readString(CONFIG_PATH), FpsBoostConfig.class);
            if (loaded == null) {
                return new FpsBoostConfig();
            }
            loaded.sanitize();
            return loaded;
        } catch (IOException | JsonParseException e) {
            FpsBoostConfig defaults = new FpsBoostConfig();
            try {
                Files.createDirectories(CONFIG_PATH.getParent());
                Files.writeString(CONFIG_PATH, GSON.toJson(defaults));
            } catch (IOException ignored) {
            }
            return defaults;
        }
    }

    private void saveConfig() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(config));
        } catch (IOException ignored) {
            // A config write failure must not crash Minecraft.
        }
    }

    public static final class FpsBoostConfig {
        public boolean enabled = true;
        public int lowFpsThreshold = 35;
        public int recoveryFpsThreshold = 55;
        public int checkIntervalTicks = 20;
        public int reductionStep = 2;
        public int minimumRenderDistance = 4;
        public int maximumRenderDistance = 16;
        public boolean showStatusMessages = true;

        void sanitize() {
            lowFpsThreshold = clamp(lowFpsThreshold, 1, 300);
            recoveryFpsThreshold = clamp(recoveryFpsThreshold, lowFpsThreshold + 1, 300);
            checkIntervalTicks = clamp(checkIntervalTicks, 1, 200);
            reductionStep = clamp(reductionStep, 1, 16);
            minimumRenderDistance = clamp(minimumRenderDistance, 2, 32);
            maximumRenderDistance = clamp(maximumRenderDistance, minimumRenderDistance, 32);
        }

        private static int clamp(int value, int min, int max) {
            return Math.max(min, Math.min(max, value));
        }
    }
}
